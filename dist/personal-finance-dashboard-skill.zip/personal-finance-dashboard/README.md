# Personal Finance Dashboard: skill package

A portable skill for building your own interactive personal-finance dashboard with an AI assistant. It covers cash flow and a forecast to the year end, cards, spending and rewards points, savings accounts, net worth, tax, investments, retirement, loans and insurance.

## How to use it

1. **Claude:** upload `personal-finance-dashboard-skill.zip` as a skill (Settings → Capabilities → Skills). Then say "Build my personal finance dashboard".
2. **Other assistants:** attach `SKILL.md` and the files it lists. Ask the assistant to follow `SKILL.md`.
3. **Preview:** open `assets/sample-dashboard.html` in Chrome or Safari to see the finished result with a sample profile.

The package holds only made-up sample data. Your own figures go into your own dashboard's database, never into this package.

## What the assistant will ask for

It works in five stages:

1. Setup
2. Cards: statements for the last 12 months, plus points balances from each card app
3. Investments: broker holdings and tradebook, mutual-fund statement (CAS), US holdings, EPF/PPF/NPS balances
4. Salary, savings accounts, tax, cash and loans: payslip, bank balances, AIS/TIS, last filed returns
5. Insurance: policy schedules

Connectors such as your broker, an investment aggregator, email or Notion can speed this up. They are optional.
